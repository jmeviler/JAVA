package cn.edu.weizhou.cloudhomelink.android.activity;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import cn.edu.weizhou.cloudhomelink.android.R;
import cn.edu.weizhou.cloudhomelink.android.service.SpacebrewService;

public class ResultActivity extends Activity {
	Button runButton = null;
	TextView tempText = null;
	TextView humText = null;
	SpacebrewService.DataBinder binder;
	ServiceConnection conn = new ServiceConnection(){

		@Override
		public void onServiceConnected(ComponentName name, IBinder service) {
			binder = (SpacebrewService.DataBinder)service;
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			// TODO Auto-generated method stub
			
		}
	
	};
	
	//动态显示温度的Handler
	final Handler myHandler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			if(msg.what == 0x1233){
				if(binder != null){
					int temperature = binder.getTemperature();
					int humidity = binder.getHumidity();
//					System.out.println(tempText.getText());
					tempText.setText(""+temperature);
					humText.setText(""+humidity);
//					runButton.setText(String.valueOf(temperature));
				}
			}
		}
		
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.activity_result);
		
		runButton = (Button) this.findViewById(R.id.button1);
		tempText =(TextView)this.findViewById(R.id.temperature);
		humText =(TextView)this.findViewById(R.id.humidity);
		
		//启动后台Spacebrew Service
		Intent intent = new Intent();
		intent.setClass(ResultActivity.this, SpacebrewService.class);
		java.lang.System.setProperty("java.net.preferIPv6Addresses", "false");
		java.lang.System.setProperty("java.net.preferIPv4Stack", "true");
		System.out.println("Begining SpacebrewService!");
//		startService(intent);
		bindService(intent,conn,Service.BIND_AUTO_CREATE);
		
		//当单机按钮时
		runButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				
			}
		});
		
		//创建定时器，每1秒触发handler一次
		new Timer().schedule(new TimerTask(){

			@Override
			public void run() {
				myHandler.sendEmptyMessage(0x1233);				
			}
		}, 0, 1000);
		
		
	}//onCreate
	
	
}
